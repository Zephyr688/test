<?php
declare (strict_types=1);

return [
    'version' => '1.3.1',
];